const express = require('express');
const cors = require('cors');
const path = require('path');
const pool = require('./db'); // Pool is imported from db.js
require('dotenv').config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Check DB Connection at startup
pool.connect()
  .then(client => {
    console.log('Connected successfully to the database');
    client.release(); // Release the client back to the pool
  })
  .catch(err => console.error('Database connection error', err.stack));

// Login Route
app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  console.log('Received login:', username, password);

  try {
    const query = `
      SELECT 'admin' AS role, username FROM admin WHERE username = $1 AND password = $2
      
    `;

    const result = await pool.query(query, [username, password]);

    if (result.rows.length > 0) {
      const user = result.rows[0];
      res.json({ message: 'Login successful!', role: user.role });
    } else {
      res.status(401).json({ message: 'Invalid credentials' });
    }
  } catch (err) {
    console.error('Login error:', err.message);
    res.status(500).json({ message: 'Server error' });
  }
});

// --- Book Endpoints ---
// API: Add Book
app.post('/api/books', async (req, res) => {
  const {
    isbn_code,
    book_title,
    category_id,
    publication_year,
    book_edition,
    copies_total,
    location_id
  } = req.body;

  const query = `
    INSERT INTO book 
    (isbn_code, book_title, category_id, publication_year, book_edition, copies_total, location_id) 
    VALUES ($1, $2, $3, $4, $5, $6, $7)
  `;

  try {
    await pool.query(query, [
      isbn_code,
      book_title,
      category_id,
      publication_year,
      book_edition,
      copies_total,
      location_id
    ]);
    res.json({ message: 'Book added successfully!' });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error saving book to database' });
  }
});
//add member
app.post('/api/members', async (req, res) => {
  const { username, password, full_name, email, phone } = req.body;

  if (!username || !password || !full_name || !email || !phone) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const query = `
    INSERT INTO member (username, password, full_name, email, phone)
    VALUES ($1, $2, $3, $4, $5)
  `;

  try {
    await pool.query(query, [username, password, full_name, email, phone]);
    res.json({ message: 'Member added successfully!' });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error saving member to database' });
  }
});
//delete
app.delete('/api/members/:member_id', async (req, res) => {
  const { member_id } = req.params;

  const query = `
    DELETE FROM member
    WHERE member_id = $1
  `;

  try {
    const result = await pool.query(query, [member_id]);

    if (result.rowCount > 0) {
      res.json({ message: 'Member deleted successfully!' });
    } else {
      res.status(404).json({ message: 'Member not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error deleting member' });
  }
});
app.put('/api/members/:member_id', async (req, res) => {
  const { member_id } = req.params;
  const { username, password, full_name, email, phone } = req.body;

  if (!username || !password || !full_name || !email || !phone) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const query = `
    UPDATE member
    SET username = $1, password = $2, full_name = $3, email = $4, phone = $5
    WHERE member_id = $6
  `;

  try {
    const result = await pool.query(query, [username, password, full_name, email, phone, member_id]);

    if (result.rowCount > 0) {
      res.json({ message: 'Member updated successfully!' });
    } else {
      res.status(404).json({ message: 'Member not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error updating member' });
  }
});
app.post('/api/return', async (req, res) => {
  const { issue_id, return_date } = req.body;

  if (!issue_id || !return_date) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  try {
    // 1. Check if issued book exists and is currently issued
    const issuedBookRes = await pool.query(
      `SELECT status FROM issued_books WHERE issue_id = $1`,
      [issue_id]
    );

    if (issuedBookRes.rows.length === 0) {
      return res.status(404).json({ message: 'Issued book record not found' });
    }

    if (issuedBookRes.rows[0].status !== 'issued') {
      return res.status(400).json({ message: 'Book already returned' });
    }

    // 2. Update issued_books status to 'returned'
    await pool.query(
      `UPDATE issued_books SET status = 'returned' WHERE issue_id = $1`,
      [issue_id]
    );

    // 3. Insert into returns table
    const insertReturnQuery = `
      INSERT INTO returns (issue_id, return_date)
      VALUES ($1, $2)
      RETURNING return_id
    `;
    const result = await pool.query(insertReturnQuery, [issue_id, return_date]);

    res.json({
      message: 'Book returned successfully!',
      return_id: result.rows[0].return_id,
    });
  } catch (err) {
    console.error('Database error while returning book:', err);
    res.status(500).json({ message: 'Failed to return book' });
  }
});
// Get fines from ViewFines
app.get('/api/fines', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM ViewFines');
    res.json(result.rows);
  } catch (err) {
    console.error('Error retrieving fines:', err);
    res.status(500).json({ message: 'Failed to retrieve fines' });
  }
});

app.get('/api/fines', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM ViewFines ORDER BY fine_id ASC');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching fines:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

// POST add fine
app.post('/api/fines', async (req, res) => {
  const { issue_id, fine_amount } = req.body;

  if (!issue_id || fine_amount == null) {
    return res.status(400).json({ message: 'Issue ID and fine amount are required' });
  }

  try {
    const insertQuery = `
      INSERT INTO Fines (issue_id, fine_amount)
      VALUES ($1, $2)
      RETURNING fine_id
    `;
    const result = await pool.query(insertQuery, [issue_id, fine_amount]);

    res.status(201).json({ message: 'Fine added', fine_id: result.rows[0].fine_id });
  } catch (err) {
    console.error('Error adding fine:', err);
    res.status(500).json({ message: 'Failed to add fine' });
  }
});

// PUT update fine (paid_date required)
app.put('/api/fines/:fine_id', async (req, res) => {
  const { fine_id } = req.params;
  const { fine_amount, paid_date } = req.body;

  if (fine_amount == null || !paid_date) {
    return res.status(400).json({ message: 'Fine amount and paid date are required' });
  }

  try {
    const updateQuery = `
      UPDATE Fines 
      SET fine_amount = $1, paid_date = $2
      WHERE fine_id = $3
      RETURNING *
    `;
    const result = await pool.query(updateQuery, [fine_amount, paid_date, fine_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Fine not found' });
    }

    res.json({ message: 'Fine updated', fine: result.rows[0] });
  } catch (err) {
    console.error('Error updating fine:', err);
    res.status(500).json({ message: 'Failed to update fine' });
  }
});

// DELETE fine by ID
app.delete('/api/fines/:fine_id', async (req, res) => {
  const { fine_id } = req.params;

  try {
    const result = await pool.query('DELETE FROM Fines WHERE fine_id = $1 RETURNING *', [fine_id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Fine not found' });
    }

    res.json({ message: 'Fine deleted' });
  } catch (err) {
    console.error('Error deleting fine:', err);
    res.status(500).json({ message: 'Failed to delete fine' });
  }
});

app.post('/api/issue', async (req, res) => {
  const { member_id, book_id, issue_date } = req.body;

  if (!member_id || !book_id || !issue_date) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const query = `
    INSERT INTO issued_books (member_id, book_id, issue_date, status)
    VALUES ($1, $2, $3, 'issued')
    
  `;

  try {
    const result = await pool.query(query, [member_id, book_id, issue_date]);
    res.json({ message: 'Book issued successfully!', issue_id: result.rows[0].issue_id });
  } catch (err) {
    console.error('Database error while issuing book:', err);
    res.status(500).json({ message: 'Failed to issue book' });
  }
});

/// Issue a book
app.post('/api/issue', async (req, res) => {
  const { member_id, book_id, issue_date } = req.body;

  if (!member_id || !book_id || !issue_date) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const queryInsert = `
    INSERT INTO issued_books (member_id, book_id, issue_date, status)
    VALUES ($1, $2, $3, 'issued')
  `;

  try {
    await pool.query(queryInsert, [member_id, book_id, issue_date]);
    res.json({ message: 'Book issued successfully!' });
  } catch (err) {
    console.error('Database error while issuing book:', err);
    res.status(500).json({ message: 'Failed to issue book' });
  }
});


//update admin
app.put('/api/admins/:admin_id', async (req, res) => {
  const { admin_id } = req.params;
  const { username, password, full_name, phone_number } = req.body;

  // Validate all required fields
  if (!username || !password || !full_name || !phone_number) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const query = `
    UPDATE admin
    SET username = $1,
        password = $2,
        full_name = $3,
        phone_number = $4
    WHERE admin_id = $5
  `;

  try {
    const result = await pool.query(query, [
      username,
      password,
      full_name,
      phone_number,
      admin_id
    ]);

    if (result.rowCount > 0) {
      res.json({ message: 'Admin updated successfully!' });
    } else {
      res.status(404).json({ message: 'Admin not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error updating admin' });
  }
});

app.delete('/api/books/:book_id', async (req, res) => {
  const { book_id } = req.params;

  const query = `
   DELETE FROM book
   WHERE book_id = $1
  `;

  try {
    const result = await pool.query(query, [book_id]);
    if (result.rowCount > 0) {
      res.json({ message: 'Book deleted successfully!' });
    } else {
      res.status(404).json({ message: 'Book not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error deleting book from database' });
  }
});

// Get a book by ID
app.get('/api/books/:book_id', async (req, res) => {
  const { book_id } = req.params;

  const query = `
    SELECT * FROM book WHERE book_id = $1
  `;

  try {
    const result = await pool.query(query, [book_id]);

    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'Book not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching book from database' });
  }
});

// Get all books
app.get('/api/books', async (req, res) => {
  const query = `
    SELECT * FROM book
  `;

  try {
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching books from database' });
  }
});

// --- Author Endpoint ---
// API: Add Author
app.post('/api/authors', async (req, res) => {
  const { author_id, first_name, last_name } = req.body;

  if (!author_id || !first_name || !last_name) {
    return res.status(400).json({ message: 'Missing required fields.' });
  }

  const query = `
    INSERT INTO author (author_id, first_name, last_name)
    VALUES ($1, $2, $3)
  `;

  try {
    await pool.query(query, [author_id, first_name, last_name]);
    res.json({ message: 'Author added successfully!' });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Author ID already exists.' });
  }
});
// Delete author by ID
app.delete('/api/authors/:author_id', async (req, res) => {
  const { author_id } = req.params;

  const query = `
    DELETE FROM author
    WHERE author_id = $1
  `;

  try {
    const result = await pool.query(query, [author_id]);
    if (result.rowCount > 0) {
      res.json({ message: 'Author deleted successfully!' });
    } else {
      res.status(404).json({ message: 'Author not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error deleting author from database' });
  }
});
app.delete('/api/categories/:category_id', async (req, res) => {
  const { category_id } = req.params;

  const query = `
    DELETE FROM category
    WHERE category_id = $1
  `;

  try {
    const result = await pool.query(query, [category_id]);

    if (result.rowCount > 0) {
      res.json({ message: 'Category deleted successfully! All linked books were also deleted.' });
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error deleting category from database' });
  }
});
// Display author by ID
app.get('/api/authors/:author_id', async (req, res) => {
  const { author_id } = req.params;
  const query = `SELECT * FROM author WHERE author_id = $1`;

  try {
    const result = await pool.query(query, [author_id]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'Author not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching author' });
  }
});

// Display all authors
app.get('/api/authors', async (req, res) => {
  const query = `SELECT * FROM author ORDER BY author_id`;

  try {
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching authors' });
  }
});

// Display category by ID
app.get('/api/categories/:category_id', async (req, res) => {
  const { category_id } = req.params;
  const query = `SELECT * FROM category WHERE category_id = $1`;

  try {
    const result = await pool.query(query, [category_id]);
    if (result.rows.length > 0) {
      res.json(result.rows[0]);
    } else {
      res.status(404).json({ message: 'Category not found' });
    }
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching category' });
  }
});

// Display all categories
app.get('/api/categories', async (req, res) => {
  const query = `SELECT * FROM category ORDER BY category_id`;

  try {
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error fetching categories' });
  }
});
// Assuming you have `pool` from pg setup and express app defined

// Get all members
app.get('/api/members', async (req, res) => {
  const query = 'SELECT member_id, username, full_name, email, phone FROM member ORDER BY member_id';

  try {
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error retrieving members from database' });
  }
});
//deleteadmin
app.delete('/api/admins/:admin_id', async (req, res) => {
  const { admin_id } = req.params;

  try {
    // Check if admin exists
    const check = await pool.query('SELECT admin_id FROM admin WHERE admin_id = $1', [admin_id]);
    if (check.rows.length === 0) {
      return res.status(404).json({ message: 'Admin not found' });
    }

    await pool.query('DELETE FROM admin WHERE admin_id = $1', [admin_id]);

    res.json({ message: `Admin with ID ${admin_id} deleted successfully.` });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error deleting admin from database' });
  }
});


// Get member by ID
app.get('/api/members/:member_id', async (req, res) => {
  const { member_id } = req.params;
  const query = `
    SELECT member_id, username, full_name, email, phone
    FROM member
    WHERE member_id = $1
  `;

  try {
    const result = await pool.query(query, [member_id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Member not found' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error retrieving member from database' });
  }
});
// Get all admins
app.get('/api/admins', async (req, res) => {
  const query = 'SELECT admin_id, username, full_name, phone_number FROM admin ORDER BY admin_id';

  try {
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching admins:', err);
    res.status(500).json({ message: 'Error retrieving admins from database' });
  }
});
//add admin
// Make sure to have: app.use(express.json()) before routes

app.post('/api/admins', async (req, res) => {
  const { username, password, full_name, phone_number } = req.body;

  if (!username || !password || !full_name || !phone_number) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  const query = `
    INSERT INTO admin (username, password, full_name, phone_number)
    VALUES ($1, $2, $3, $4)
    RETURNING admin_id, username, full_name, phone_number
  `;

  try {
    const result = await pool.query(query, [username, password, full_name, phone_number]);
    res.json({ message: 'Admin added successfully!', admin: result.rows[0] });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Error saving admin to database' });
  }
});

// Get admin by ID
app.get('/api/admins/:admin_id', async (req, res) => {
  const { admin_id } = req.params;
  const query = `
    SELECT * FROM view_admin_basic_info
WHERE admin_id = 1;

  `;

  try {
    const result = await pool.query(query, [admin_id]);
    if (result.rows.length === 0) {
      return res.status(404).json({ message: 'Admin not found' });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error('Error fetching admin:', err);
    res.status(500).json({ message: 'Error retrieving admin from database' });
  }
});
app.post('/api/fine', async (req, res) => {
  const { fine_id, mem_id, book_id, issue_id, fine_amount, paid_date } = req.body;

  if ( !mem_id || !book_id || !issue_id || !fine_amount || !paid_date) {
    return res.status(400).json({ message: 'Missing required fields.' });
  }

  const query = `
    INSERT INTO fines ( mem_id, book_id, issue_id, fine_amount, paid_date)
    VALUES ($1, $2, $3, $4, $5)
  `;

  try {
    await pool.query(query, [fine_id, mem_id, book_id, issue_id, fine_amount, paid_date]);
    res.json({ message: 'Fine added successfully!' });
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).json({ message: 'Fine ID may already exist or a foreign key is invalid.' });
  }
});
app.get('/met',async(req,res)=>{
    try{
        const result=await pool.query('select count(*) from book');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message})
    }
});

app.get('/he',async(req,res)=>{
    try{
        const result=await pool.query('select count(*) from member ');
        res.json(result.rows);
    }catch(err){
        res.status(500).json({Error:err.message})
    }
});



// Start Server
const PORT = process.env.PORT || 5005;
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
