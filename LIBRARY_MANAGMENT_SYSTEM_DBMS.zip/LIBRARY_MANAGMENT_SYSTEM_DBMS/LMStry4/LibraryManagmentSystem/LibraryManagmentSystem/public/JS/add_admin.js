document.getElementById('addAdminForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const full_name = document.getElementById('full_name').value.trim();
  const phone_number = document.getElementById('phone_number').value.trim();
  const password = document.getElementById('password').value;

  if (!username || !full_name || !phone_number || !password) {
    alert('Please fill all fields');
    return;
  }

  try {
    const res = await fetch('http://localhost:5005/api/admins', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, full_name, phone_number, password }),
    });

    if (!res.ok) {
      const errorData = await res.json();
      throw new Error(errorData.message || 'Failed to add admin');
    }

    alert('Admin added successfully!');
    e.target.reset();
  } catch (err) {
    alert(err.message);
  }
});
