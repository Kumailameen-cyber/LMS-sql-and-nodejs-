document.addEventListener('DOMContentLoaded', () => {
  const displayBookForm = document.getElementById('displayBookForm');
  const viewAllBooksButton = document.getElementById('viewAllBooks');
  const bookDetailsDiv = document.getElementById('bookDetails');
  const bookTable = document.getElementById('bookTable');
  const tableBody = document.querySelector('#bookTable tbody');

  // Function to display a single book
  async function displayBook(book_id) {
   try {
    const res = await fetch(`http://localhost:5005/api/books/${book_id}`);
    const book = await res.json();

    if (res.ok) {
     let detailsHTML = `
            <p><strong>Book ID:</strong> ${book.book_id}</p>
            <p><strong>ISBN Code:</strong> ${book.isbn_code}</p>
            <p><strong>Book Title:</strong> ${book.book_title}</p>
            <p><strong>Category ID:</strong> ${book.category_id}</p>
            <p><strong>Publication Year:</strong> ${book.publication_year}</p>
            <p><strong>Book Edition:</strong> ${book.book_edition}</p>
            <p><strong>Copies Total:</strong> ${book.copies_total}</p>
            <p><strong>Copies Available:</strong> ${book.copies_available}</p>
            <p><strong>Location ID:</strong> ${book.location_id}</p>
          `;
     bookDetailsDiv.innerHTML = detailsHTML;
     bookDetailsDiv.style.display = 'block';
     bookTable.style.display = 'none';
    } else {
     alert(book.message);
    }
   } catch (err) {
    alert('Failed to display book');
    console.error(err);
   }
  }

  // Function to display all books
  async function displayAllBooks() {
   try {
    const res = await fetch('http://localhost:5005/api/books');
    const books = await res.json();

    tableBody.innerHTML = ''; // Clear existing rows

    books.forEach(book => {
     const row = document.createElement('tr');
     row.innerHTML = `
            <td>${book.book_id}</td>
            <td>${book.isbn_code}</td>
            <td>${book.book_title}</td>
            <td>${book.category_id}</td>
            <td>${book.publication_year}</td>
            <td>${book.book_edition}</td>
            <td>${book.copies_total}</td>
            <td>${book.copies_available}</td>
            <td>${book.location_id}</td>
          `;
     tableBody.appendChild(row);
    });

    bookDetailsDiv.style.display = 'none';
    bookTable.style.display = 'table';
   } catch (err) {
    console.error('Error fetching books:', err);
    alert('Failed to fetch books');
   }
  }

  // Event listener for displaying a single book
  displayBookForm.addEventListener('submit', async (e) => {
   e.preventDefault();
   const book_id = document.getElementById('book_id').value;
   displayBook(book_id);
  });

  // Event listener for displaying all books
  viewAllBooksButton.addEventListener('click', displayAllBooks);
 });