document.getElementById('deleteAdminForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const admin_id = document.getElementById('admin_id').value;

  try {
    const res = await fetch(`/api/admins/${admin_id}`, {
      method: 'DELETE',
    });

    const result = await res.json();
    alert(result.message);
    if (res.ok) document.getElementById('deleteAdminForm').reset();
  } catch (err) {
    alert('Failed to delete admin');
    console.error(err);
  }
});
