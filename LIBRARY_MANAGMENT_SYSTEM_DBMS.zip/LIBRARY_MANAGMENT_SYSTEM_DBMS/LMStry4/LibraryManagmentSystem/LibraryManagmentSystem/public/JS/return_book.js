document.getElementById('returnBookForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const issue_id = document.getElementById('return_issue_id').value.trim();
  const return_date = document.getElementById('return_date').value;

  try {
    const res = await fetch('http://localhost:5005/api/return', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ issue_id, return_date }),
    });

    const data = await res.json();

    if (res.ok) {
      alert(data.message);
      e.target.reset();
    } else {
      alert(data.message || 'Failed to return book');
    }
  } catch (err) {
    console.error('Error:', err);
    alert('An error occurred while returning the book.');
  }
});
