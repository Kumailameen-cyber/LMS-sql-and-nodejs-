document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('addCategoryForm');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const category_name = document.getElementById('category_name').value;

    try {
      const response = await fetch('http://localhost:5005/api/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ category_name })
      });

      const data = await response.json();
      console.log('Success:', data);
      alert(data.message || 'Category added successfully!');
      form.reset();
    } catch (error) {
      console.error('Error:', error);
      alert('Error adding category. Check console for details.');
    }
  });
});
