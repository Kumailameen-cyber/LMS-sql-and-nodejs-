 document.getElementById('deleteBookForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const book_id = document.getElementById('book_id').value;

  try {
   const res = await fetch(`/api/books/${book_id}`, {
    method: 'DELETE',
   });

   const result = await res.json();
   alert(result.message);
   if (res.ok) document.getElementById('deleteBookForm').reset();
  } catch (err) {
   alert('Failed to delete book');
   console.error(err);
  }
 });
 