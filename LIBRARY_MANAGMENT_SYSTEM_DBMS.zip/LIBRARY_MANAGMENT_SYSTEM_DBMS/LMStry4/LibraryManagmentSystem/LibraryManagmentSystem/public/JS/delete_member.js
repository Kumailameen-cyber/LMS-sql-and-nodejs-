document.getElementById('deleteMemberForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const member_id = document.getElementById('member_id').value;

  try {
    const res = await fetch(`http://localhost:5005/api/members/${member_id}`, {
      method: 'DELETE',
    });

    const data = await res.json();
    alert(data.message);

    if (res.ok) {
      document.getElementById('deleteMemberForm').reset();
    }
  } catch (err) {
    alert('Failed to delete member');
    console.error(err);
  }
});
