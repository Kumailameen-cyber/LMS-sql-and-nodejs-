document.getElementById('displayMemberForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const memberId = document.getElementById('member_id').value.trim();
  const memberDetailsDiv = document.getElementById('memberDetails');
  const memberTable = document.getElementById('memberTable');
  const tbody = memberTable.querySelector('tbody');

  memberDetailsDiv.innerHTML = '';
  memberTable.style.display = 'none';
  tbody.innerHTML = '';

  if (!memberId) {
    alert('Please enter a Member ID');
    return;
  }

  try {
    const res = await fetch(`http://localhost:5005/api/members/${memberId}`);
    if (!res.ok) {
      const errData = await res.json();
      throw new Error(errData.message || 'Failed to fetch member');
    }

    const member = await res.json();

    // Show member details
    memberDetailsDiv.innerHTML = `
      <h3>Member Details</h3>
      <ul>
        <li><strong>Member ID:</strong> ${member.member_id}</li>
        <li><strong>Username:</strong> ${member.username}</li>
        <li><strong>Full Name:</strong> ${member.full_name}</li>
        <li><strong>Email:</strong> ${member.email}</li>
        <li><strong>Phone:</strong> ${member.phone}</li>
       
      </ul>
    `;
  } catch (err) {
    alert(err.message);
  }
});

document.getElementById('viewAllMembers').addEventListener('click', async () => {
  const memberDetailsDiv = document.getElementById('memberDetails');
  const memberTable = document.getElementById('memberTable');
  const tbody = memberTable.querySelector('tbody');

  memberDetailsDiv.innerHTML = '';
  tbody.innerHTML = '';

  try {
    const res = await fetch('http://localhost:5005/api/members');
    if (!res.ok) throw new Error('Failed to fetch members');

    const members = await res.json();

    if (members.length === 0) {
      memberDetailsDiv.innerHTML = '<p>No members found.</p>';
      memberTable.style.display = 'none';
      return;
    }

    // Populate table rows
    members.forEach(m => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${m.member_id}</td>
        <td>${m.username}</td>
        <td>${m.full_name}</td>
        <td>${m.email}</td>
        <td>${m.phone}</td>
       
      `;
      tbody.appendChild(tr);
    });

    memberTable.style.display = 'table';
  } catch (err) {
    alert(err.message);
  }
});
