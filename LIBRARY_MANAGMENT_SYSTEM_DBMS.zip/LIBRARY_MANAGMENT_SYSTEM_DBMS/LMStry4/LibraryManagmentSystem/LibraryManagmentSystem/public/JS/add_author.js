document.getElementById('addAuthorForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const authorId = document.getElementById('author_id').value;
    const firstName = document.getElementById('first_name').value;
    const lastName = document.getElementById('last_name').value;

    try {
        const res = await fetch('http://localhost:5005/api/authors', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                author_id: authorId,
                first_name: firstName,
                last_name: lastName
            })
        });

        const text = await res.text(); 

        if (!res.ok) {
            throw new Error(`Server Error: ${res.status} - ${text}`);
        }

        const data = text ? JSON.parse(text) : {};
        alert(data.message || 'Author added successfully!');
        document.getElementById('addAuthorForm').reset();

    } catch (err) {
        alert(err.message);
        console.error('Error:', err);
    }
});
