document.getElementById('displayAuthorForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const author_id = document.getElementById('author_id').value.trim();
  const detailsDiv = document.getElementById('authorDetails');
  const table = document.getElementById('authorTable');
  const tbody = table.querySelector('tbody');
  detailsDiv.innerHTML = '';
  table.style.display = 'none';

  if (!author_id) {
    alert('Please enter an Author ID.');
    return;
  }

  try {
    const res = await fetch(`/api/authors/${author_id}`);
    if (!res.ok) {
      const error = await res.json();
      alert(error.message || 'Author not found');
      return;
    }
    const author = await res.json();

    detailsDiv.innerHTML = `
      <h3>Author Details</h3>
      <p><strong>Author ID:</strong> ${author.author_id}</p>
      <p><strong>First Name:</strong> ${author.first_name}</p>
      <p><strong>Last Name:</strong> ${author.last_name}</p>
    `;
  } catch (err) {
    alert('Failed to fetch author data');
    console.error(err);
  }
});

document.getElementById('viewAllAuthors').addEventListener('click', async () => {
  const detailsDiv = document.getElementById('authorDetails');
  const table = document.getElementById('authorTable');
  const tbody = table.querySelector('tbody');
  detailsDiv.innerHTML = '';
  tbody.innerHTML = '';

  try {
    const res = await fetch('http://localhost:5005/api/authors');
    if (!res.ok) throw new Error('Failed to fetch authors');
    const authors = await res.json();

    if (authors.length === 0) {
      detailsDiv.innerHTML = '<p>No authors found.</p>';
      return;
    }

    authors.forEach((author) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${author.author_id}</td>
        <td>${author.first_name}</td>
        <td>${author.last_name}</td>
      `;
      tbody.appendChild(row);
    });

    table.style.display = 'table';
  } catch (err) {
    alert(err.message);
    console.error(err);
  }
});
