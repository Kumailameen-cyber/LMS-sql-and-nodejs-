document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('addBookForm');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const isbn_code = document.getElementById('isbn_code').value;
        const book_title = document.getElementById('book_title').value;
        const category_id = document.getElementById('category_id').value;
        const publication_year = document.getElementById('publication_year').value;
        const book_edition = document.getElementById('book_edition').value;
        const copies_total = document.getElementById('copies_total').value;
        const location_id = document.getElementById('location_id').value;

        try {
            const response = await fetch('http://localhost:5005/api/books', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    isbn_code,
                    book_title,
                    category_id,
                    publication_year,
                    book_edition,
                    copies_total,
                    location_id
                })
            });

            const data = await response.json();
            console.log('Success:', data);
            alert(data.message || 'Book added successfully!');
        } catch (error) {
            console.error('Error:', error);
            alert('Error adding book. Check console for details.');
        }
    });
});
