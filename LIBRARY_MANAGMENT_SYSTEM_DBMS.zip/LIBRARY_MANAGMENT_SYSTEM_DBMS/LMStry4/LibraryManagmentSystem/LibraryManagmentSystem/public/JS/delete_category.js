document.getElementById('deleteCategoryForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const category_id = document.getElementById('category_id').value;

  if (!category_id) {
    alert('Please enter a Category ID');
    return;
  }

  const confirmDelete = confirm(
    'Deleting this category will also delete all books linked to it. Are you sure?'
  );
  if (!confirmDelete) return;

  try {
    const res = await fetch(`/api/categories/${category_id}`, {
      method: 'DELETE',
    });

    const result = await res.json();
    alert(result.message);

    if (res.ok) {
      document.getElementById('deleteCategoryForm').reset();
    }
  } catch (err) {
    alert('Failed to delete category');
    console.error(err);
  }
});
