document.getElementById('issueBookForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const member_id = document.getElementById('member_id').value.trim();
  const book_id = document.getElementById('book_id').value.trim();
  const issue_date = document.getElementById('issue_date').value;

  try {
    const res = await fetch('http://localhost:5005/api/issue', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ member_id, book_id, issue_date }),
    });

    const data = await res.json();

    if (res.ok) {
      alert(data.message);
      e.target.reset();
    } else {
      alert(data.message || 'Failed to issue book');
    }
  } catch (err) {
    console.error('Error:', err);
    alert('An error occurred while issuing the book.');
  }
});
