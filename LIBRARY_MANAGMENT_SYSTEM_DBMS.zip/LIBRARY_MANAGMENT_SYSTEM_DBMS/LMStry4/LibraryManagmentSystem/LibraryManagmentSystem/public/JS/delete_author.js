document.getElementById('deleteAuthorForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const author_id = document.getElementById('author_id').value;

  try {
    const res = await fetch(`/api/authors/${author_id}`, {
      method: 'DELETE',
    });

    const result = await res.json();
    alert(result.message);
    if (res.ok) document.getElementById('deleteAuthorForm').reset();
  } catch (err) {
    alert('Failed to delete author');
    console.error(err);
  }
});
