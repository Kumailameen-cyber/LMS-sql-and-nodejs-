document.getElementById('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('email').value.trim();
  const password = document.getElementById('password').value;

  try {
    const response = await fetch('http://localhost:5005/login', { // Explicit backend URL here
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    const data = await response.json();

    if (response.ok) {
      alert(data.message);
      if (data.role === 'admin') {
        window.location.href = 'admin/admin.html';
      }
    } else {
      alert(data.message);
    }
  } catch (error) {
    alert('An error occurred. Please try again.');
    console.error(error);  // changed from 'err' to 'error' to match the catch block variable
  }
});
