document.getElementById('updateAdminForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const admin_id = document.getElementById('admin_id').value;
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const full_name = document.getElementById('full_name').value;
  const phone_number = document.getElementById('phone_number').value;

  try {
    const res = await fetch(`http://localhost:5005/api/admins/${admin_id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, full_name, phone_number }),
    });

    const data = await res.json();
    if (res.ok) {
      alert(data.message || 'Admin updated successfully!');
      document.getElementById('updateAdminForm').reset();
    } else {
      alert(data.message || 'Failed to update admin');
    }
  } catch (err) {
    alert('Error updating admin');
    console.error(err);
  }
});
