document.getElementById('updateMemberForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const member_id = document.getElementById('member_id').value;
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
  const full_name = document.getElementById('full_name').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;

  try {
    const res = await fetch(`http://localhost:5005/api/members/${member_id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, full_name, email, phone }),
    });

    const data = await res.json();
    if (res.ok) {
      alert(data.message || 'Member updated successfully!');
      document.getElementById('updateMemberForm').reset();
    } else {
      alert(data.message || 'Failed to update member');
    }
  } catch (err) {
    alert('Error updating member');
    console.error(err);
  }
});
