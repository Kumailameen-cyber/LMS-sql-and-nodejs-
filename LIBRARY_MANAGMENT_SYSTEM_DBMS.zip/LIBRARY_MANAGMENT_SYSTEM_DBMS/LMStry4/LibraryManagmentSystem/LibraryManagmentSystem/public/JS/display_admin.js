document.getElementById('searchByIdBtn').addEventListener('click', async () => {
  const adminId = document.getElementById('admin_id').value.trim();
  const resultDiv = document.getElementById('adminResult');
  resultDiv.innerHTML = '';

  if (!adminId) {
    alert('Please enter an Admin ID');
    return;
  }

  try {
    const res = await fetch(`http://localhost:5005/api/admins/${adminId}`);
    if (!res.ok) {
      const data = await res.json();
      throw new Error(data.message || 'Failed to fetch admin');
    }

    const admin = await res.json();
    resultDiv.innerHTML = `
      <h3>Admin Details</h3>
      <ul>
        <li><strong>Admin ID:</strong> ${admin.admin_id}</li>
        <li><strong>Username:</strong> ${admin.username}</li>
        <li><strong>Full Name:</strong> ${admin.full_name}</li>
        <li><strong>Phone:</strong> ${admin.phone_number}</li>
      </ul>
    `;
  } catch (err) {
    resultDiv.innerHTML = `<p class="text-danger">${err.message}</p>`;
  }
});

document.getElementById('loadAllBtn').addEventListener('click', async () => {
  const resultDiv = document.getElementById('adminResult');
  resultDiv.innerHTML = '';

  try {
    const res = await fetch('http://localhost:5005/api/admins');
    if (!res.ok) throw new Error('Failed to fetch admins');

    const admins = await res.json();
    if (admins.length === 0) {
      resultDiv.innerHTML = '<p>No admins found.</p>';
      return;
    }

    let tableHTML = `
      <table class="table table-bordered">
        <thead class="table-light">
          <tr>
            <th>Admin ID</th>
            <th>Username</th>
            <th>Full Name</th>
            <th>Phone</th>
          </tr>
        </thead>
        <tbody>
    `;

    admins.forEach(admin => {
      tableHTML += `
        <tr>
          <td>${admin.admin_id}</td>
          <td>${admin.username}</td>
          <td>${admin.full_name}</td>
          <td>${admin.phone_number}</td>
        </tr>
      `;
    });

    tableHTML += '</tbody></table>';
    resultDiv.innerHTML = tableHTML;
  } catch (err) {
    resultDiv.innerHTML = `<p class="text-danger">${err.message}</p>`;
  }
});
