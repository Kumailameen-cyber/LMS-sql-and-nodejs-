document.getElementById('addMemberForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;
  const full_name = document.getElementById('full_name').value.trim();
  const email = document.getElementById('email').value.trim();
  const phone = document.getElementById('phone').value.trim();

  try {
    const res = await fetch('http://localhost:5005/api/members', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password, full_name, email, phone })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.message || 'Failed to add member');

    alert(data.message);
    e.target.reset();
  } catch (err) {
    alert(err.message);
    console.error(err);
  }
});
