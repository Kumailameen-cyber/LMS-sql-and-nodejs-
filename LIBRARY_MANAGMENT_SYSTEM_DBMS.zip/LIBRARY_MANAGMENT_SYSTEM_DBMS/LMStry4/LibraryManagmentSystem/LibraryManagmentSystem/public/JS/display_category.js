document.getElementById('displayCategoryForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const category_id = document.getElementById('category_id').value.trim();
  const detailsDiv = document.getElementById('categoryDetails');
  const table = document.getElementById('categoryTable');
  const tbody = table.querySelector('tbody');
  detailsDiv.innerHTML = '';
  table.style.display = 'none';

  if (!category_id) {
    alert('Please enter a Category ID.');
    return;
  }

  try {
    const res = await fetch(`/api/categories/${category_id}`);
    if (!res.ok) {
      const error = await res.json();
      alert(error.message || 'Category not found');
      return;
    }
    const category = await res.json();

    detailsDiv.innerHTML = `
      <h3>Category Details</h3>
      <p><strong>Category ID:</strong> ${category.category_id}</p>
      <p><strong>Category Name:</strong> ${category.category_name}</p>
    `;
  } catch (err) {
    alert('Failed to fetch category data');
    console.error(err);
  }
});

document.getElementById('viewAllCategories').addEventListener('click', async () => {
  const detailsDiv = document.getElementById('categoryDetails');
  const table = document.getElementById('categoryTable');
  const tbody = table.querySelector('tbody');
  detailsDiv.innerHTML = '';
  tbody.innerHTML = '';

  try {
    const res = await fetch('http://localhost:5005/api/categories');
    if (!res.ok) throw new Error('Failed to fetch categories');
    const categories = await res.json();

    if (categories.length === 0) {
      detailsDiv.innerHTML = '<p>No categories found.</p>';
      return;
    }

    categories.forEach((category) => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${category.category_id}</td>
        <td>${category.category_name}</td>
      `;
      tbody.appendChild(row);
    });

    table.style.display = 'table';
  } catch (err) {
    alert(err.message);
    console.error(err);
  }
});
